#include "stockfish_bridge.h"

#include <condition_variable>
#include <algorithm>
#include <chrono>
#include <mutex>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

#include "../src/attacks.h"
#include "../src/engine.h"
#include "../src/misc.h"
#include "../src/position.h"
#include "../src/search.h"
#include "../src/tune.h"
#include "../src/uci.h"
#include "../src/ucioption.h"

struct ChessapeakeStockfish {
    Stockfish::Engine engine;
    std::mutex engineMutex;
    std::mutex outputMutex;
    std::condition_variable bestmoveReady;
    std::string bestmove;
    std::vector<std::string> transcript;

    ChessapeakeStockfish() : engine(std::nullopt) {
        engine.set_on_iter([](const Stockfish::Engine::InfoIter&) {});

        engine.set_on_update_no_moves([this](const Stockfish::Engine::InfoShort& info) {
            std::stringstream ss;
            ss << "info depth " << info.depth
               << " score " << Stockfish::UCIEngine::format_score(info.score);
            std::lock_guard<std::mutex> lock(outputMutex);
            transcript.push_back(ss.str());
        });

        engine.set_on_update_full([this](const Stockfish::Engine::InfoFull& info) {
            std::stringstream ss;
            ss << "info";
            ss << " depth " << info.depth
               << " seldepth " << info.selDepth
               << " multipv " << info.multiPV
               << " score " << Stockfish::UCIEngine::format_score(info.score);

            if (!info.bound.empty()) {
                ss << " " << info.bound;
            }

            ss << " nodes " << info.nodes
               << " nps " << info.nps
               << " hashfull " << info.hashfull
               << " tbhits " << info.tbHits
               << " time " << info.timeMs
               << " pv " << info.pv;

            std::lock_guard<std::mutex> lock(outputMutex);
            transcript.push_back(ss.str());
        });

        engine.set_on_bestmove([this](std::string_view move, std::string_view ponder) {
            {
                std::lock_guard<std::mutex> lock(outputMutex);
                bestmove = std::string(move);
                if (!ponder.empty()) {
                    bestmove += " ponder ";
                    bestmove += std::string(ponder);
                }
                transcript.push_back("bestmove " + bestmove);
            }
            bestmoveReady.notify_all();
        });

        engine.set_on_verify_network([](std::string_view) {});
    }
};

namespace {

std::once_flag stockfishInitFlag;
thread_local std::string lastResult;

void initialize_stockfish_once() {
    std::call_once(stockfishInitFlag, [] {
        Stockfish::Attacks::init();
        Stockfish::Position::init();
    });
}

std::vector<std::string> split_moves(const char* moves) {
    std::vector<std::string> result;
    if (moves == nullptr) {
        return result;
    }

    std::istringstream stream(moves);
    std::string token;
    while (stream >> token) {
        result.push_back(token);
    }
    return result;
}

void set_option(Stockfish::Engine& engine, const std::string& name, int value) {
    std::istringstream stream("name " + name + " value " + std::to_string(value));
    engine.get_options().setoption(stream);
}

void set_bool_option(Stockfish::Engine& engine, const std::string& name, bool value) {
    std::istringstream stream("name " + name + " value " + std::string(value ? "true" : "false"));
    engine.get_options().setoption(stream);
}

std::string run_search(
    ChessapeakeStockfish* engine,
    const char* fen,
    const char* moves,
    int depth,
    int movetime_ms,
    int multipv,
    bool transcript
) {
    if (engine == nullptr || fen == nullptr) {
        return "";
    }

    std::unique_lock<std::mutex> engineLock(engine->engineMutex);
    engine->engine.wait_for_search_finished();

    if (multipv > 0) {
        set_option(engine->engine, "MultiPV", std::max(1, multipv));
    }

    set_bool_option(engine->engine, "UCI_LimitStrength", false);

    Stockfish::Search::LimitsType limits;
    limits.startTime = Stockfish::now();
    if (depth > 0) {
        limits.depth = depth;
    }
    if (movetime_ms > 0) {
        limits.movetime = movetime_ms;
    }

    {
        std::lock_guard<std::mutex> outputLock(engine->outputMutex);
        engine->bestmove.clear();
        engine->transcript.clear();
    }

    if (engine->engine.set_position(fen, split_moves(moves)).has_value()) {
        std::lock_guard<std::mutex> outputLock(engine->outputMutex);
        engine->transcript.push_back("info string invalid position rejected");
        return "";
    }
    engine->engine.go(limits);

    engine->engine.wait_for_search_finished();
    engineLock.unlock();

    std::unique_lock<std::mutex> outputLock(engine->outputMutex);
    engine->bestmoveReady.wait_for(outputLock, std::chrono::seconds(5), [&] { return !engine->bestmove.empty(); });

    if (!transcript) {
        return engine->bestmove;
    }

    std::stringstream output;
    for (const auto& line : engine->transcript) {
        output << line << "\n";
    }
    return output.str();
}

}  // namespace

ChessapeakeStockfish* chessapeake_stockfish_create(void) {
    initialize_stockfish_once();
    return new ChessapeakeStockfish();
}

void chessapeake_stockfish_destroy(ChessapeakeStockfish* engine) {
    if (engine != nullptr) {
        std::lock_guard<std::mutex> lock(engine->engineMutex);
        engine->engine.stop();
        engine->engine.wait_for_search_finished();
    }
    delete engine;
}

const char* chessapeake_stockfish_version(void) {
    lastResult = Stockfish::engine_info(false);
    return lastResult.c_str();
}

const char* chessapeake_stockfish_bestmove(
    ChessapeakeStockfish* engine,
    const char* fen,
    const char* moves,
    int depth,
    int movetime_ms
) {
    lastResult = run_search(engine, fen, moves, depth, movetime_ms, 1, false);
    return lastResult.c_str();
}

const char* chessapeake_stockfish_search_transcript(
    ChessapeakeStockfish* engine,
    const char* fen,
    const char* moves,
    int depth,
    int movetime_ms,
    int multipv
) {
    lastResult = run_search(engine, fen, moves, depth, movetime_ms, multipv, true);
    return lastResult.c_str();
}

void chessapeake_stockfish_stop(ChessapeakeStockfish* engine) {
    if (engine == nullptr) {
        return;
    }
    std::lock_guard<std::mutex> lock(engine->engineMutex);
    engine->engine.stop();
}

void chessapeake_stockfish_set_skill(ChessapeakeStockfish* engine, int skill) {
    if (engine == nullptr) {
        return;
    }
    std::lock_guard<std::mutex> lock(engine->engineMutex);
    set_option(engine->engine, "Skill Level", std::clamp(skill, 0, 20));
}

void chessapeake_stockfish_set_threads(ChessapeakeStockfish* engine, int threads) {
    if (engine == nullptr) {
        return;
    }
    std::lock_guard<std::mutex> lock(engine->engineMutex);
    set_option(engine->engine, "Threads", std::max(1, threads));
}

void chessapeake_stockfish_set_hash(ChessapeakeStockfish* engine, int megabytes) {
    if (engine == nullptr) {
        return;
    }
    std::lock_guard<std::mutex> lock(engine->engineMutex);
    set_option(engine->engine, "Hash", std::max(1, megabytes));
}

void chessapeake_stockfish_set_multipv(ChessapeakeStockfish* engine, int multipv) {
    if (engine == nullptr) {
        return;
    }
    std::lock_guard<std::mutex> lock(engine->engineMutex);
    set_option(engine->engine, "MultiPV", std::max(1, multipv));
}
