/*
  Chessapeake Stockfish bridge.

  This header exposes a small C ABI for an in-process iOS build of Stockfish.
  Stockfish is GPLv3-or-later; linking this bridge into the app links Stockfish
  into the app and carries the corresponding license obligations.
*/

#ifndef CHESSAPEAKE_STOCKFISH_BRIDGE_H
#define CHESSAPEAKE_STOCKFISH_BRIDGE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ChessapeakeStockfish ChessapeakeStockfish;

ChessapeakeStockfish* chessapeake_stockfish_create(void);
void chessapeake_stockfish_destroy(ChessapeakeStockfish* engine);

const char* chessapeake_stockfish_version(void);
const char* chessapeake_stockfish_bestmove(
    ChessapeakeStockfish* engine,
    const char* fen,
    const char* moves,
    int depth,
    int movetime_ms
);
const char* chessapeake_stockfish_search_transcript(
    ChessapeakeStockfish* engine,
    const char* fen,
    const char* moves,
    int depth,
    int movetime_ms,
    int multipv
);
void chessapeake_stockfish_stop(ChessapeakeStockfish* engine);

void chessapeake_stockfish_set_skill(ChessapeakeStockfish* engine, int skill);
void chessapeake_stockfish_set_threads(ChessapeakeStockfish* engine, int threads);
void chessapeake_stockfish_set_hash(ChessapeakeStockfish* engine, int megabytes);
void chessapeake_stockfish_set_multipv(ChessapeakeStockfish* engine, int multipv);

#ifdef __cplusplus
}
#endif

#endif
