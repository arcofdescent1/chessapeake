# Stockfish Vendor Notes

Chessapeake vendors official Stockfish source at the stable `sf_19` tag.

- Repository: `https://github.com/official-stockfish/Stockfish.git`
- Tag: `sf_19`
- Commit observed when vendored: `edb0d9db6731067ec50ce619ff372b463bc4dd5d`
- License: GPLv3-or-later

## iOS Integration Shape

iOS should not rely on launching a bundled Stockfish executable. Instead, build
Stockfish as a static library/XCFramework and call it in process through the
small C ABI in `Chessapeake/stockfish_bridge.h`.

The Swift app remains behind the `ChessEngine` protocol. Stockfish, a cloud
engine, or Cameron's custom chess engine can all satisfy the same app contract.

## Build

From the `Chessapeake` project folder:

```sh
Scripts/build-stockfish-ios-xcframework.sh
```

The script emits `Frameworks/Stockfish.xcframework`. That framework is linked
into the app target as a static XCFramework, and Swift imports it through the
module map generated beside `stockfish_bridge.h`.

## App Store Note

Linking Stockfish into an app links GPLv3-or-later code into that app. Before
shipping, decide whether the full app will comply with GPL terms, whether the
engine will be distributed separately, or whether the custom engine replaces
Stockfish for release builds.
