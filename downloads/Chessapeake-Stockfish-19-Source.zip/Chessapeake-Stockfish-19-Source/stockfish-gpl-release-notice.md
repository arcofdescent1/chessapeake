# Stockfish GPL Release Notice

Last updated: 2026-11-09

Chessapeake bundles Stockfish 19 through `Frameworks/Stockfish.xcframework`. Stockfish is GPLv3-or-later software by the Stockfish developers. The framework is statically linked, and its complete matching source is packaged by `Scripts/package-stockfish-source.sh`.

## Required Release Package

- Include `Vendor/Stockfish/Copying.txt`.
- Include `Vendor/Stockfish/AUTHORS`.
- Include the complete vendored Stockfish source under `Vendor/Stockfish`.
- Include `Vendor/Stockfish/Chessapeake/stockfish_bridge.h` and `Vendor/Stockfish/Chessapeake/stockfish_bridge.cpp`.
- Include `Scripts/build-stockfish-ios-xcframework.sh`.
- Include `Scripts/package-stockfish-source.sh` output in release artifacts.
- Include the NNUE network with its SHA-256 provenance.
- Include the exact upstream tag and commit, compiler flags, deployment target, bridge checksums, binary checksums, and a complete source manifest.
- State that `Frameworks/Stockfish.xcframework` was built from the included source package.

## In-App Notice

Chessapeake bundles Stockfish 19, a GPLv3-or-later chess engine by the Stockfish developers. The exact engine source, GPL license, build notes, NNUE network, and Chessapeake bridge modifications are available in the matching Chessapeake Stockfish 19 source package.

## Release Gate

- The release owner records counsel's approval of the combined-work distribution model.
- The exact source package is published at a durable HTTPS URL at least as accessible as the binary.
- The in-app notice and App Store review notes provide that URL and identify Stockfish as GPLv3-or-later.
- Any engine, bridge, compiler, or distribution change invalidates the recorded approval and source-package checksum.
