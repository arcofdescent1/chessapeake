#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STOCKFISH_DIR="$ROOT_DIR/Vendor/Stockfish"
SRC_DIR="$STOCKFISH_DIR/src"
BRIDGE_DIR="$STOCKFISH_DIR/Chessapeake"
BUILD_DIR="$ROOT_DIR/Build/Stockfish"
OUTPUT_DIR="$ROOT_DIR/Frameworks"
HEADER_DIR="$BUILD_DIR/Headers"
EVAL_NET="nn-1a298aa575a0.nnue"

SOURCES=(
  "$SRC_DIR/benchmark.cpp"
  "$SRC_DIR/attacks.cpp"
  "$SRC_DIR/bitboard.cpp"
  "$SRC_DIR/evaluate.cpp"
  "$SRC_DIR/misc.cpp"
  "$SRC_DIR/movegen.cpp"
  "$SRC_DIR/movepick.cpp"
  "$SRC_DIR/position.cpp"
  "$SRC_DIR/search.cpp"
  "$SRC_DIR/thread.cpp"
  "$SRC_DIR/timeman.cpp"
  "$SRC_DIR/tt.cpp"
  "$SRC_DIR/uci.cpp"
  "$SRC_DIR/ucioption.cpp"
  "$SRC_DIR/tune.cpp"
  "$SRC_DIR/syzygy/tbprobe.cpp"
  "$SRC_DIR/nnue/nnue_accumulator.cpp"
  "$SRC_DIR/nnue/nnue_misc.cpp"
  "$SRC_DIR/nnue/network.cpp"
  "$SRC_DIR/nnue/features/half_ka_v2_hm.cpp"
  "$SRC_DIR/nnue/features/full_threats.cpp"
  "$SRC_DIR/nnue/features/pp_3wide.cpp"
  "$SRC_DIR/engine.cpp"
  "$SRC_DIR/score.cpp"
  "$SRC_DIR/memory.cpp"
  "$BRIDGE_DIR/stockfish_bridge.cpp"
)

COMMON_FLAGS=(
  -std=c++20
  -stdlib=libc++
  -O3
  -DNDEBUG
  -DIS_64BIT
  -DNO_PREFETCH
  -fvisibility=hidden
  -I"$SRC_DIR"
  -I"$BRIDGE_DIR"
)

build_slice() {
  local platform="$1"
  local arch="$2"
  local sdk="$3"
  local min_version="$4"
  local slice_dir="$BUILD_DIR/$platform-$arch"
  local objects_dir="$slice_dir/Objects"
  local lib_path="$slice_dir/libStockfish.a"

  mkdir -p "$objects_dir"
  rm -f "$lib_path"

  local sdk_path
  sdk_path="$(xcrun --sdk "$sdk" --show-sdk-path)"

  for source in "${SOURCES[@]}"; do
    local object="$objects_dir/$(basename "$source").o"
    xcrun clang++ "${COMMON_FLAGS[@]}" \
      -arch "$arch" \
      -isysroot "$sdk_path" \
      -m"$min_version" \
      -c "$source" \
      -o "$object"
  done

  xcrun ar -rcs "$lib_path" "$objects_dir"/*.o
}

rm -rf "$BUILD_DIR"
mkdir -p "$HEADER_DIR" "$OUTPUT_DIR"
cp "$BRIDGE_DIR/stockfish_bridge.h" "$HEADER_DIR/stockfish_bridge.h"
cp "$BRIDGE_DIR/module.modulemap" "$HEADER_DIR/module.modulemap"

if [[ ! -f "$SRC_DIR/$EVAL_NET" ]]; then
  echo "Stockfish NNUE files are missing. Downloading and validating official nets..."
  (cd "$SRC_DIR" && ../scripts/net.sh)
fi

build_slice iphoneos arm64 iphoneos iphoneos-version-min=17.0
build_slice iphonesimulator arm64 iphonesimulator iphonesimulator-version-min=17.0

rm -rf "$OUTPUT_DIR/Stockfish.xcframework"
xcodebuild -create-xcframework \
  -library "$BUILD_DIR/iphoneos-arm64/libStockfish.a" -headers "$HEADER_DIR" \
  -library "$BUILD_DIR/iphonesimulator-arm64/libStockfish.a" -headers "$HEADER_DIR" \
  -output "$OUTPUT_DIR/Stockfish.xcframework"

echo "Built $OUTPUT_DIR/Stockfish.xcframework"
