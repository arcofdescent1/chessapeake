#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/../ReleaseArtifacts}"
ARCHIVE_NAME="Chessapeake-Stockfish-19-Source"
TEMP_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/chessapeake-stockfish.XXXXXX")"
PACKAGE_DIR="$TEMP_ROOT/$ARCHIVE_NAME"
ARCHIVE_PATH="$OUTPUT_DIR/$ARCHIVE_NAME.zip"
trap 'rm -rf "$TEMP_ROOT"' EXIT

mkdir -p "$PACKAGE_DIR" "$OUTPUT_DIR"
rm -f "$ARCHIVE_PATH"

mkdir -p "$PACKAGE_DIR/Stockfish"
COPYFILE_DISABLE=1 rsync -a \
  --exclude '.git/' \
  --exclude '._*' \
  --exclude '.DS_Store' \
  "$ROOT_DIR/Vendor/Stockfish/" "$PACKAGE_DIR/Stockfish/"
mkdir -p "$PACKAGE_DIR/Scripts"
cp "$ROOT_DIR/Scripts/build-stockfish-ios-xcframework.sh" "$PACKAGE_DIR/Scripts/"
cp "$ROOT_DIR/docs/stockfish-gpl-release-notice.md" "$PACKAGE_DIR/"
cp "$ROOT_DIR/Scripts/package-stockfish-source.sh" "$PACKAGE_DIR/Scripts/"

cat > "$PACKAGE_DIR/BUILD-NOTES.txt" <<NOTES
Chessapeake Stockfish source package.

Upstream: https://github.com/official-stockfish/Stockfish.git
Tag: sf_19
Commit: edb0d9db6731067ec50ce619ff372b463bc4dd5d
License: GPLv3-or-later

The distributed Frameworks/Stockfish.xcframework was built from this source
with Scripts/build-stockfish-ios-xcframework.sh using Apple clang++, C++20,
libc++, -O3, -DNDEBUG, -DIS_64BIT, -DNO_PREFETCH, hidden symbol visibility,
arm64 device and arm64 simulator slices, and an iOS 17.0 minimum target.

NNUE network:
nn-1a298aa575a0.nnue
SHA-256 $(shasum -a 256 "$ROOT_DIR/Vendor/Stockfish/src/nn-1a298aa575a0.nnue" | awk '{print $1}')

Chessapeake bridge modifications are complete in
Stockfish/Chessapeake/stockfish_bridge.h and stockfish_bridge.cpp. No other
patch set is applied to the upstream sf_19 source.
NOTES

{
  shasum -a 256 "$ROOT_DIR/Frameworks/Stockfish.xcframework/ios-arm64/libStockfish.a" | sed 's#  .*#  Frameworks/Stockfish.xcframework/ios-arm64/libStockfish.a#'
  shasum -a 256 "$ROOT_DIR/Frameworks/Stockfish.xcframework/ios-arm64-simulator/libStockfish.a" | sed 's#  .*#  Frameworks/Stockfish.xcframework/ios-arm64-simulator/libStockfish.a#'
  shasum -a 256 "$PACKAGE_DIR/Stockfish/Chessapeake/stockfish_bridge.cpp" | sed 's#  .*#  Stockfish/Chessapeake/stockfish_bridge.cpp#'
  shasum -a 256 "$PACKAGE_DIR/Stockfish/Chessapeake/stockfish_bridge.h" | sed 's#  .*#  Stockfish/Chessapeake/stockfish_bridge.h#'
} > "$PACKAGE_DIR/BINARY-CHECKSUMS.txt"

(
  cd "$PACKAGE_DIR"
  find Stockfish Scripts -type f -print0 | sort -z | xargs -0 shasum -a 256 > SOURCE-SHA256SUMS.txt
)

(
  cd "$TEMP_ROOT"
  /usr/bin/zip -qry "$ARCHIVE_PATH" "$ARCHIVE_NAME"
)

echo "$ARCHIVE_PATH"
